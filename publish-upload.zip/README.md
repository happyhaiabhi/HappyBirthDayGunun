# 🎂 Happy Birthday Shristi! 🌷

A magical birthday surprise website made with 💜 for **Shristi** — **26th November**!

## ✨ What's inside
- 🎉 A sparkling full-screen mobile birthday card with a floating photo collage
- 🎁 Six surprise gifts — flowers, chocolate, rasmalai, **coffee** & pani puri coupons, and a special video
- 🎂 A cake-cutting page with the birthday video
- 💌 Secret coupon codes — redeemable on WhatsApp! 😉

## 🎬 Before publishing — add the videos!
Upload these two files into this same folder (repo root), with exactly these names:

| File | Where it's used |
|---|---|
| `cake.mp4` | "Cut the Cake" page |
| `special.mp4` | The special video gift |

*(Until then, the pages show lovely photo posters instead — nothing looks broken.)*

## 🚀 How to publish (GitHub Pages)
1. Upload **all files** from this folder (plus `cake.mp4` + `special.mp4`) to the repo root.
2. Settings → Pages → Source: **Deploy from a branch** → **main** / **(root)** → Save.
3. Live at: `https://happyhaiabhi.github.io/Happy-Birthday-Shristi/`

---

*Made with love. Happy Birthday, Shristi! 🥳🌸*
